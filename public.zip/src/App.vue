<script setup>
  // import AdminBoardView from './views/AdminBoardView.vue';
  // import ChoosingCard from './views/СhoosingCardView.vue'
</script>

<template>
  <RouterView/>
</template>



