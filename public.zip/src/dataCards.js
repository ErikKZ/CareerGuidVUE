export default [
  {
    id: 1,
    idType : 1, 
    titleTxt: 'Фотография',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 2,
    idType : 1, 
    titleTxt: 'Дизайн',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 3,
    idType : 1, 
    titleTxt: 'Музыка',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 4,
    idType : 1, 
    titleTxt: 'искусство',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 5,
    idType : 1, 
    titleTxt: 'режиссура',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 6,
    idType : 1, 
    titleTxt: 'стиль одежды',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 7,
    idType : 1, 
    titleTxt: 'архитектура',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 8,
    idType : 1, 
    titleTxt: 'красота человека',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 9,
    idType : 1, 
    titleTxt: 'художественные тексты',
    typeTitle: 'творчество',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 10,
    idType : 2, 
    titleTxt: 'Фотография',
    typeTitle: '',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 11,
    idType : 2, 
    titleTxt: 'Дизайн',
    typeTitle: '',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 12,
    idType : 2, 
    titleTxt: 'Музыка',
    typeTitle: '',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 13,
    idType : 3, 
    titleTxt: 'престиж компании',
    typeTitle: '',
    iconUrl: 'Photo',
    isSelected: false
  },
  {
    id: 14,
    idType : 3, 
    titleTxt: 'внешний вид',
    typeTitle: '',
    iconUrl: 'Photo',
    isSelected: false
  },
]
